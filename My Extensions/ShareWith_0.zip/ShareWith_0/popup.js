
//var allowed_url = "https://www.jtracker.com/account/order/";
var allowed_url = "https://www.jtracker.com/account/order/";

$(function () {
    chrome.tabs.getSelected(null, function(tab) {

        if(!tab.url.includes(allowed_url)) {
            chrome.storage.sync.get({
                api_key: "",
                api_pin: "",
                userID: ""
            }, function (items) {
                // console.log(items);
                // if (items.api_key == "" && items.api_pin == "") {
                //     $('#login-wrapper').removeClass('d-none');
                // } else {
                //     $('#user-wrapper').removeClass('d-none');
                //     $('#userName').text(items.userID);
                // }
            });
        }
        else {
            $('#wrapper').html("");
            swal({
                title: "",
                text: 'Please visit the "Order Page" on jtracker.com in order to use this extension!',
                confirmButtonClass: "btn-danger",
                confirmButtonText: "OK",
                closeOnConfirm: true
            },
            function(){
                window.close();
            });
        }

    });
});

$(document).on('submit', '#loginForm', function (e) {

    e.preventDefault();
    var loading = $('#loading');
    loading.removeClass('d-none');
    var userEmail = $('#inputEmail').val();
    var userPwd = $('#inputPassword').val();






    $('#userName').text(userEmail);
                $('#login-wrapper').addClass('d-none');
                $('#user-wrapper').removeClass('d-none');

    // $.ajax({
    //     url: "https://dispatchcenter.com/loadboard/api/getAPICreds/",
    //     type: "POST",
    //     data: JSON.stringify({"email": userEmail, "password": userPwd}),
    //     dataType: 'json',
    //     success: function(response) {
    //         loading.addClass('d-none');
    //         if ( response.status === 'success') {
    //             chrome.storage.sync.set({
    //                 "api_key": response['data']['api_key'],
    //                 "api_pin": response['data']['api_pin'],
    //                 "userID": userEmail
    //             }, function () {
    //             });
    //             $('#userName').text(userEmail);
    //             $('#login-wrapper').addClass('d-none');
    //             $('#user-wrapper').removeClass('d-none');
    //         } else {
    //             $('#loginForm')[0].reset();
    //             swal('', response.error_msg);
    //         }
    //     },
    //     error: function (request, status, error) {
    //         swal('', 'An error occurred. Please try again');
    //     }
    // });

});

$(document).on('click', '#logout', function () {

    $('#login-wrapper').removeClass('d-none');
    $('#user-wrapper').addClass('d-none');
    var loading = $('#loading');
    loading.addClass('d-none');
    chrome.storage.sync.set({
        api_key: "",
        api_pin: "",
        userID: ""
    }, function () {
    });
    
});