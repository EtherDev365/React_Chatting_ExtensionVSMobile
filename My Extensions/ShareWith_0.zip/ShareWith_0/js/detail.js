var submitForm = false;

$(document).ready(function() {
	$('form[name="postToCDForm"]').on('submit', function(e){
		// validation code here
		if(!submitForm) {
			return false;
		}
		else {
			submitForm = false;
			return true;
		}
	});
});

// $("input[value='Post to CD']").attr("disabled", true);
var api_key = "";
var api_pin = "";


$("input[value='Post to CD']").on('click', function() {
	var id = $("input[name='lqo_id']").val();
	
    chrome.storage.sync.get({
        api_key: "",
        api_pin: "",
        userID: ""
    }, function (items) {
        if (items.api_key == "" && items.api_pin == "") {
        	submitForm = true;
			$('form[name="postToCDForm"]').trigger('submit');
        } else {
            api_key = items.api_key;
            api_pin = items.api_pin;
            $("input[name='cd_additional_info']").val("");
            clickedPCDbutton(id);
        }
	});  
});

function clickedPCDbutton(id){
    var div = $("#pop_posttocd");
    var old_img = $("#img_loading");
    if(old_img) old_img.remove();

    var img = document.createElement("img");
    img.id = "img_loading";
    var imgURL = chrome.extension.getURL("img/loading.gif");
    img.src= imgURL;
    img.style= "width:50px; position:absolute; top:45%; left:45%;"
    div[0].appendChild(img);
    myFetch(id);
}

async function myFetch(id) {
    try {
        let response = await fetch('https://www.jtracker.com/account/order/form.php?lqo_id=' + id);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }else {
            let html = await response.text();
            parseData(html, id);
        }
    } catch(e) {
      console.log(e);
    }
}

function parseData(html, id){
    const parser = new DOMParser();
    const htmlDoc = parser.parseFromString(html, "text/html");
    
    var custom_order_id = htmlDoc.querySelector(".pageheader em").innerHTML;
    var o_contact_name = htmlDoc.querySelector('#pickup_contact') ? htmlDoc.querySelector('#pickup_contact').value : "";
    var o_phone1 = htmlDoc.querySelector('#pickup_phone') ?  htmlDoc.querySelector('#pickup_phone').value : "";
    var o_phone2 = htmlDoc.querySelector('#pickup_phone2') ?  htmlDoc.querySelector('#pickup_phone2').value : "";
    var o_cell = htmlDoc.querySelector('#pickup_phone_cell') ?  htmlDoc.querySelector('#pickup_phone_cell').value : "";
    var o_fax = htmlDoc.querySelector('#pickup_phone_fax') ? htmlDoc.querySelector('#pickup_phone_fax').value : "";
    var o_address1 = htmlDoc.querySelector('#pickup_address') ?  htmlDoc.querySelector('#pickup_address').value : "";
    var o_address2 = htmlDoc.querySelector('#pickup_address2') ?  htmlDoc.querySelector('#pickup_address2').value : "";
    var o_city = htmlDoc.querySelector('#pickup_city') ?  htmlDoc.querySelector('#pickup_city').value : "";
    var o_state = htmlDoc.querySelector('#pickup_state_code') ?  htmlDoc.querySelector('#pickup_state_code').value : "";
    var o_zip = htmlDoc.querySelector('#pickup_zip') ?  htmlDoc.querySelector('#pickup_zip').value : "";

    var d_contact_name = htmlDoc.querySelector('#dropoff_contact') ? htmlDoc.querySelector('#dropoff_contact').value : "";
    var d_phone1 = htmlDoc.querySelector('#dropoff_phone') ?  htmlDoc.querySelector('#dropoff_phone').value : "";
    var d_phone2 = htmlDoc.querySelector('#dropoff_phone2') ?  htmlDoc.querySelector('#dropoff_phone2').value : "";
    var d_cell = htmlDoc.querySelector('#dropoff_phone_cell') ?  htmlDoc.querySelector('#dropoff_phone_cell').value : "";
    var d_fax = htmlDoc.querySelector('#dropoff_phone_fax') ? htmlDoc.querySelector('#dropoff_phone_fax').value : "";
    var d_address1 = htmlDoc.querySelector('#dropoff_address') ?  htmlDoc.querySelector('#dropoff_address').value : "";
    var d_address2 = htmlDoc.querySelector('#dropoff_address2') ?  htmlDoc.querySelector('#dropoff_address2').value : "";
    var d_city = htmlDoc.querySelector('#dropoff_city') ?  htmlDoc.querySelector('#dropoff_city').value : "";
    var d_state = htmlDoc.querySelector('#dropoff_state_code') ?  htmlDoc.querySelector('#dropoff_state_code').value : "";
    var d_zip = htmlDoc.querySelector('#dropoff_zip') ?  htmlDoc.querySelector('#dropoff_zip').value : "";

    var ship_date = htmlDoc.querySelector('#first_pickup_date') ? htmlDoc.querySelector('#first_pickup_date').value : "";
    var date_to_pickup = htmlDoc.querySelector('#local_date_type') ? htmlDoc.querySelector('#local_date_type').value : "";
    var date_to_deliver = htmlDoc.querySelector('#delviery_date_type') ? htmlDoc.querySelector('#delviery_date_type').value : "";
    var carrier_type = htmlDoc.querySelector('#ship_via_id') ? htmlDoc.querySelector('#ship_via_id').value : "";

	var ii = 1;
    var vehicles = [];
    while (true) {
        nii = ii + 1;
        if(!(htmlDoc.querySelector('#vehicle_type_id' + nii)))
            break;
        var veh_type =htmlDoc.querySelector('#vehicle_type_id' + ii) ? htmlDoc.querySelector('#vehicle_type_id' + ii).value : "";
        var veh_make = htmlDoc.querySelector('#make' + ii) ? htmlDoc.querySelector('#make' + ii).value : "";
        var veh_model = htmlDoc.querySelector('#model' + ii) ? htmlDoc.querySelector('#model' + ii).value : "";
        var veh_year = htmlDoc.querySelector('#year' + ii) ? htmlDoc.querySelector('#year' + ii).value : "";
        var veh_vin = htmlDoc.querySelector('#vin' + ii) ? htmlDoc.querySelector('#vin' + ii).value : "";
        var veh_license_plate = htmlDoc.querySelector('#plate' + ii) ? htmlDoc.querySelector('#plate' + ii).value : "";
        var veh_color = htmlDoc.querySelector('#color' + ii) ? htmlDoc.querySelector('#color' + ii).value : "";
        var veh_op = htmlDoc.querySelector('#vehicle_runs') ? htmlDoc.querySelector('#vehicle_runs').value : "";
        var veh_state = htmlDoc.querySelector('#plate_state_code' + ii) ? htmlDoc.querySelector('#plate_state_code' + ii).value : "";
        var veh_notes = "";
        var veh_lot_number = htmlDoc.querySelector('#lot_number' + ii) ? htmlDoc.querySelector('#lot_number' + ii).value : "";
        var veh_load = 0;

        var one_v =  {
                "veh_type":veh_type,
                "veh_make":veh_make,
                "veh_model":veh_model,
                "veh_year":veh_year,
                "veh_vin":veh_vin,
                "veh_license_plate":veh_license_plate,
                "veh_color":veh_color,
                "veh_op":veh_op,
                "veh_state":veh_state,
                "veh_notes":veh_notes,
                "veh_lot_number":veh_lot_number,
                "veh_load":veh_load
            };
        vehicles.push(one_v);

        ii ++;
    }

    var carrier_pay = htmlDoc.querySelector('#carrier_pay') ? htmlDoc.querySelector('#carrier_pay').value : "";
    var cod_cop_amount = "";
    var payment_method = htmlDoc.querySelector('#cod_payment_method') ? htmlDoc.querySelector('#cod_payment_method').value : "";
    var payment_location = "";
    var balance_amount = "";
    var balance_method = htmlDoc.querySelector('#order_balance_type_id') ? htmlDoc.querySelector('#order_balance_type_id').value : "";
    var balance_time = "";
    var balance_term = "";
    var additional_information = "";
    var special_instructions = "";
    var listing_type = "";
    var is_for_dispatch = false;

    var pdata = {
        "order_id":"",
        "custom_order_id":custom_order_id,
        "o_contact_name":o_contact_name,
        "o_phone1":o_phone1,
        "o_phone2":o_phone1,
        "o_cell":o_cell,
        "o_fax":o_fax,
        "o_address1":o_address1,
        "o_address2":o_address2,
        "o_city":o_city,
        "o_state":o_state,
        "o_zip":o_zip,
        "d_contact_name":d_contact_name,
        "d_phone1":d_phone1,
        "d_phone2":d_phone2,
        "d_cell":d_cell,
        "d_fax":d_fax,
        "d_address1":d_address1,
        "d_address2":d_address2,
        "d_city":d_city,
        "d_state":d_state,
        "d_zip":d_zip,
        "ship_date":ship_date,
        "date_to_pickup":date_to_pickup,
        "date_to_deliver":date_to_deliver,
        "carrier_type":carrier_type,
        "Vehicles" : vehicles,
        "carrier_pay":carrier_pay,
        "cod_cop_amount":cod_cop_amount,
        "payment_method":payment_method,
        "payment_location":payment_location,
        "balance_amount":balance_amount,
        "balance_method":balance_method,
        "balance_time":balance_time,
        "balance_term":balance_term,
        "additional_information":additional_information,
        "special_instructions":special_instructions,
        "listing_type":listing_type,
        "is_for_dispatch":is_for_dispatch
    };
     username = api_key;
     password = api_pin;

     console.log(pdata);

    $.ajax({
        url: "https://dispatchcenter.com/loadboard/api/post-listing/",
        type: "POST",
        data: JSON.stringify(pdata),
        dataType: 'json',
        beforeSend: function (xhr) {
            xhr.setRequestHeader ("Authorization", "Basic " + btoa(username + ":" + password));
        },
        success: function(response) {
            if ( response['Status'] == 1001 || response['Status'] == 1002) {
                var shortlink = response['Shortlink'];    
                postCD(shortlink, id);                       
            } else {              
                console.log(response);
                var img = $("#img_loading");
                img.remove();
                alert("Failed to get shortlink, try again.");
            }
        },
        error: function (request, status, error) {
            console.log(error);
            var img = $("#img_loading");
            img.remove();
                alert("Failed to get shortlink, try again.");
        }
    });
}

function postCD(shortlink, id){
    $("input[name='cd_additional_info']").val(shortlink);
   	submitForm = true;
	$('form[name="postToCDForm"]').trigger('submit');
}