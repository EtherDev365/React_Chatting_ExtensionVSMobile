(function($) {
    orderListing = {
        preProcessBeforePostToCd: function(str_id) {
            var id = str_id.replace("post_to_cd_str-", "");
            $div = $("#post_to_cd_div-" + id);
            setTimeout(findPCDbutton, 100, id);
            return;
            if (orderListing.pcd_cache[id]) {
                //console.log($div.find("input[type=button]"));
            } else {
                setTimeout(() => {
                    $("input[value='Post to CD']").attr("disabled", true);
                    $("input[value='Post to CD']").click(function() {
                        alert('User clicked on "foo."');
                    });
                    orderListing.pcd_cache[id] = true;
                }, 2000);
            }
        },
        cache: {},
        pcd_cache: {}
    };
}) (jQuery);

preWindowLoaded();

function preWindowLoaded() {

    $('a[id*="post_to_cd_str-"]').each(function(i){
        document.getElementById($(this).attr('id')).addEventListener("click", function(e){
             orderListing.preProcessBeforePostToCd($(this).attr('id'));
        });      
    });

    return;

    // $( "form#OForm table tbody tr").each(function( i ) {
    //     var oneA = $(this).find("td");
    //     if(oneA.length >= 9){
    //         var aa = $(oneA[8]).find('a');
    //         document.getElementById($(aa[0]).attr('id')).addEventListener("click", function(e){
    //             orderListing.preProcessBeforePostToCd($(aa[0]).attr('id'));
    //         });    
    //     }
        
    // });
    // $.map($("#OForm table tbody tr td:eq(8) a"), function(a) {
    //     document.getElementById($(a).attr('id')).addEventListener("click", function(e){
    //         orderListing.preProcessBeforePostToCd($(a).attr('id'));

    //     });
    // });
}

var api_key = "";
var api_pin = "";

function findPCDbutton(id){
    var pcd_div = $("#post_to_cd_div-" + id);
    var pcd_button =[];
    if(pcd_div){        
        pcd_button = pcd_div.find("input[value='Post to CD']");    
    }
    
    if(pcd_button.length == 0){
        setTimeout(findPCDbutton, 30, id);
    }else if(pcd_button[0].style.display =="none"){       
        setTimeout(findPCDbutton, 30, id);
    }else{
        var add_input = $("#cd_additional_info-" + id);
        add_input.val("");

        chrome.storage.sync.get({
                api_key: "",
                api_pin: "",
                userID: ""
            }, function (items) {
                if (items.api_key == "" && items.api_pin == "") {
                    // pcd_button[0].style.display="none";
                    // var div = pcd_button[0].parentElement;
                    // var input = document.createElement("input");
                    // input.id = "temp_button";
                    // input.type = "button";
                    // input.addEventListener("click", function(e){
                    //     var pcd_button = $("input[value='Post to CD']");
                    //     pcd_button.click();
                    // });
                    // div.appendChild(input);
                } else {
                    api_key = items.api_key;
                    api_pin = items.api_pin;                    

                    pcd_button[0].style.display="none";                    
                    var div = pcd_button[0].parentElement;
                    var input = document.createElement("input");
                    input.id = "temp_button_" + id;
                    input.type = "button";
                    input.addEventListener("click", function(e){
                        clickedPCDbutton(id);
                    });
                    div.appendChild(input);
                }
        });       
    }
}

function clickedPCDbutton(id){
    var temp_button =$("#temp_button_" + id);
    var div = temp_button[0].parentElement.parentElement.parentElement.parentElement;
    var img = document.createElement("img");
    img.id = "img_loading_" + id;
    var imgURL = chrome.extension.getURL("img/loading.gif");
    img.src= imgURL;
    img.style= "width:50px; position:absolute; top:45%; left:45%;"
    div.appendChild(img);
    myFetch(id);
}

async function myFetch(id) {
    try {
        let response = await fetch('https://www.jtracker.com/account/order/form.php?lqo_id=' + id);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }else {
            let html = await response.text();
            parseData(html, id);
        }
    } catch(e) {
      console.log(e);
    }
}

function parseData(html, id){
    const parser = new DOMParser();
    const htmlDoc = parser.parseFromString(html, "text/html");
    
    var custom_order_id = htmlDoc.querySelector(".pageheader em").innerHTML;
    var o_contact_name = htmlDoc.querySelector('#pickup_contact') ? htmlDoc.querySelector('#pickup_contact').value : "";
    var o_phone1 = htmlDoc.querySelector('#pickup_phone') ?  htmlDoc.querySelector('#pickup_phone').value : "";
    var o_phone2 = htmlDoc.querySelector('#pickup_phone2') ?  htmlDoc.querySelector('#pickup_phone2').value : "";
    var o_cell = htmlDoc.querySelector('#pickup_phone_cell') ?  htmlDoc.querySelector('#pickup_phone_cell').value : "";
    var o_fax = htmlDoc.querySelector('#pickup_phone_fax') ? htmlDoc.querySelector('#pickup_phone_fax').value : "";
    var o_address1 = htmlDoc.querySelector('#pickup_address') ?  htmlDoc.querySelector('#pickup_address').value : "";
    var o_address2 = htmlDoc.querySelector('#pickup_address2') ?  htmlDoc.querySelector('#pickup_address2').value : "";
    var o_city = htmlDoc.querySelector('#pickup_city') ?  htmlDoc.querySelector('#pickup_city').value : "";
    var o_state = htmlDoc.querySelector('#pickup_state_code') ?  htmlDoc.querySelector('#pickup_state_code').value : "";
    var o_zip = htmlDoc.querySelector('#pickup_zip') ?  htmlDoc.querySelector('#pickup_zip').value : "";

    var d_contact_name = htmlDoc.querySelector('#dropoff_contact') ? htmlDoc.querySelector('#dropoff_contact').value : "";
    var d_phone1 = htmlDoc.querySelector('#dropoff_phone') ?  htmlDoc.querySelector('#dropoff_phone').value : "";
    var d_phone2 = htmlDoc.querySelector('#dropoff_phone2') ?  htmlDoc.querySelector('#dropoff_phone2').value : "";
    var d_cell = htmlDoc.querySelector('#dropoff_phone_cell') ?  htmlDoc.querySelector('#dropoff_phone_cell').value : "";
    var d_fax = htmlDoc.querySelector('#dropoff_phone_fax') ? htmlDoc.querySelector('#dropoff_phone_fax').value : "";
    var d_address1 = htmlDoc.querySelector('#dropoff_address') ?  htmlDoc.querySelector('#dropoff_address').value : "";
    var d_address2 = htmlDoc.querySelector('#dropoff_address2') ?  htmlDoc.querySelector('#dropoff_address2').value : "";
    var d_city = htmlDoc.querySelector('#dropoff_city') ?  htmlDoc.querySelector('#dropoff_city').value : "";
    var d_state = htmlDoc.querySelector('#dropoff_state_code') ?  htmlDoc.querySelector('#dropoff_state_code').value : "";
    var d_zip = htmlDoc.querySelector('#dropoff_zip') ?  htmlDoc.querySelector('#dropoff_zip').value : "";

    var ship_date = htmlDoc.querySelector('#first_pickup_date') ? htmlDoc.querySelector('#first_pickup_date').value : "";
    var date_to_pickup = htmlDoc.querySelector('#local_date_type') ? htmlDoc.querySelector('#local_date_type').value : "";
    var date_to_deliver = htmlDoc.querySelector('#delviery_date_type') ? htmlDoc.querySelector('#delviery_date_type').value : "";
    var carrier_type = htmlDoc.querySelector('#ship_via_id') ? htmlDoc.querySelector('#ship_via_id').value : "";

    var ii = 1;
    var vehicles = [];
    while (true) {
        nii = ii + 1;
        if(!(htmlDoc.querySelector('#vehicle_type_id' + nii)))
            break;
        var veh_type =htmlDoc.querySelector('#vehicle_type_id' + ii) ? htmlDoc.querySelector('#vehicle_type_id' + ii).value : "";
        var veh_make = htmlDoc.querySelector('#make' + ii) ? htmlDoc.querySelector('#make' + ii).value : "";
        var veh_model = htmlDoc.querySelector('#model' + ii) ? htmlDoc.querySelector('#model' + ii).value : "";
        var veh_year = htmlDoc.querySelector('#year' + ii) ? htmlDoc.querySelector('#year' + ii).value : "";
        var veh_vin = htmlDoc.querySelector('#vin' + ii) ? htmlDoc.querySelector('#vin' + ii).value : "";
        var veh_license_plate = htmlDoc.querySelector('#plate' + ii) ? htmlDoc.querySelector('#plate' + ii).value : "";
        var veh_color = htmlDoc.querySelector('#color' + ii) ? htmlDoc.querySelector('#color' + ii).value : "";
        var veh_op = htmlDoc.querySelector('#vehicle_runs') ? htmlDoc.querySelector('#vehicle_runs').value : "";
        var veh_state = htmlDoc.querySelector('#plate_state_code' + ii) ? htmlDoc.querySelector('#plate_state_code' + ii).value : "";
        var veh_notes = "";
        var veh_lot_number = htmlDoc.querySelector('#lot_number' + ii) ? htmlDoc.querySelector('#lot_number' + ii).value : "";
        var veh_load = 0;

        var one_v =  {
                "veh_type":veh_type,
                "veh_make":veh_make,
                "veh_model":veh_model,
                "veh_year":veh_year,
                "veh_vin":veh_vin,
                "veh_license_plate":veh_license_plate,
                "veh_color":veh_color,
                "veh_op":veh_op,
                "veh_state":veh_state,
                "veh_notes":veh_notes,
                "veh_lot_number":veh_lot_number,
                "veh_load":veh_load
            };
        vehicles.push(one_v);

        ii ++;
    }

    var carrier_pay = htmlDoc.querySelector('#carrier_pay') ? htmlDoc.querySelector('#carrier_pay').value : "";
    var cod_cop_amount = "";
    var payment_method = htmlDoc.querySelector('#cod_payment_method') ? htmlDoc.querySelector('#cod_payment_method').value : "";
    var payment_location = "";
    var balance_amount = "";
    var balance_method = htmlDoc.querySelector('#order_balance_type_id') ? htmlDoc.querySelector('#order_balance_type_id').value : "";
    var balance_time = "";
    var balance_term = "";
    var additional_information = "";
    var special_instructions = "";
    var listing_type = "";
    var is_for_dispatch = false;

    var pdata = {
        "order_id":"",
        "custom_order_id":custom_order_id,
        "o_contact_name":o_contact_name,
        "o_phone1":o_phone1,
        "o_phone2":o_phone1,
        "o_cell":o_cell,
        "o_fax":o_fax,
        "o_address1":o_address1,
        "o_address2":o_address2,
        "o_city":o_city,
        "o_state":o_state,
        "o_zip":o_zip,
        "d_contact_name":d_contact_name,
        "d_phone1":d_phone1,
        "d_phone2":d_phone2,
        "d_cell":d_cell,
        "d_fax":d_fax,
        "d_address1":d_address1,
        "d_address2":d_address2,
        "d_city":d_city,
        "d_state":d_state,
        "d_zip":d_zip,
        "ship_date":ship_date,
        "date_to_pickup":date_to_pickup,
        "date_to_deliver":date_to_deliver,
        "carrier_type":carrier_type,
        "Vehicles" : vehicles,
        "carrier_pay":carrier_pay,
        "cod_cop_amount":cod_cop_amount,
        "payment_method":payment_method,
        "payment_location":payment_location,
        "balance_amount":balance_amount,
        "balance_method":balance_method,
        "balance_time":balance_time,
        "balance_term":balance_term,
        "additional_information":additional_information,
        "special_instructions":special_instructions,
        "listing_type":listing_type,
        "is_for_dispatch":is_for_dispatch
    };
     username = api_key;
     password = api_pin;
     
    $.ajax({
        url: "https://dispatchcenter.com/loadboard/api/post-listing/",
        type: "POST",
        data: JSON.stringify(pdata),
        dataType: 'json',
        crossDomain: true,
        beforeSend: function (xhr) {
            xhr.setRequestHeader ("Authorization", "Basic " + btoa(username + ":" + password));
        },
        success: function(response) {
            if ( response['Status'] == 1001 || response['Status'] == 1002) {
                var shortlink = response['Shortlink'];    
                postCD(shortlink, id);                       
            } else {              
                console.log(response);
                var img = $("#img_loading_" + id);
                img.remove();
                alert("Failed to get shortlink... try again.");
            }
        },
        error: function (request, status, error) {
            console.log(error);
            var img = $("#img_loading_" + id);
            img.remove();
            alert("Failed to get shortlink, try again.");
        }
    });
}

function postCD(shortlink, id){
    var add_input = $("#cd_additional_info-" + id);
    add_input.val(shortlink);
    var pcd_div = $("#post_to_cd_div-" + id);
    if(pcd_div){
        pcd_button = pcd_div.find("input[value='Post to CD']");   
        pcd_button.click(); 
    }    
}